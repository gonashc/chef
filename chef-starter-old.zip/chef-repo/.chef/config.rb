# See http://docs.chef.io/config_rb.html for more information on knife configuration options

current_dir = File.dirname(__FILE__)
log_level                :info
log_location             STDOUT
node_name                "nash_3007"
client_key               "#{current_dir}/nash_3007.pem"
chef_server_url          "https://api.chef.io/organizations/naresh_3007"
cookbook_path            ["#{current_dir}/../cookbooks"]
